import numpy as np

def cost_function(x, y, theta0, theta1):
    """Compute the squared error cost function

    Inputs:
    x        vector of length m containing x values
    y        vector of length m containing y values
    theta_0  (scalar) intercept parameter
    theta_1  (scalar) slope parameter

    Returns:
    cost     (scalar) the cost
    """

    cost = 0.0

    ##################################################
    # TODO: write code here to compute cost correctly
    ##################################################
    
    # finding the overall cost using the given function   
    cost = (np.sum((y-(theta1*x + theta0))**2))/2
    return cost

def gradient(x, y, theta0, theta1):
    """Compute the partial derivative of the squared error cost function

    Inputs:
    x          vector of length m containing x values
    y          vector of length m containing y values
    theta_0    (scalar) intercept parameter
    theta_1    (scalar) slope parameter

    Returns:
    d_theta_0  (scalar) Partial derivative of cost function wrt theta_0
    d_theta_1  (scalar) Partial derivative of cost function wrt theta_1
    """

    d_theta_0 = 0.0
    d_theta_1 = 0.0

    ##################################################
    # TODO: write code here to compute partial derivatives correctly
    ##################################################

    # calculating the value of the partial derivatives with respect to theta_0 and theta_1
    
    # the partial derivative with respect to theta_0
    d_theta_0 = np.sum((-1)*(y-(theta1*x + theta0))) 
        
    # the partial derivative with respect to theta_1
    d_theta_1 = np.sum(((-1)*x)*(y-(theta1*x + theta0)))


    return d_theta_0, d_theta_1 # return is a tuple

